package edu.jsu.mcis;

public interface ShapeObserver {
    public void shapeChanged(ShapeEvent event);
}